<?php include_once "includes/header.php" ?>
<?php
include_once "includes/header.php";
if (!isset($_SESSION['user_id'])){
    ?>
    <script type="text/javascript">
        window.location.href="logout";
    </script>
    <?php
    exit();
}

?>
    <section>
        <div class="container py-5">
            <div class="py-3">
                <h1 class="text-primary fw-bolder">AWESOME WORK!</h1>
                <p>You're on your way to mastering this business and our process. Every appointment helps you get hands on
                    experience and teaches you how simple it is to duplicate getting a result. Aim to leverage the expertise
                    of the amazing trainers we have and lastly our main goal is to properly train you before you go off on
                    your own.</p>
            </div>
        </div>
    </section>


<?php include_once "includes/footer.php" ?>